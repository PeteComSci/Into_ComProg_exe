# number_checker.py

def main():
    
    # TODO: Prompt the user to enter an integer and store it in the variable 'number'.
    
    
    # TODO: Determine if the number is positive, negative, or zero and print the appropriate message.
    # Hint: Use comparison operators (>, <, ==) to check if the number is positive, negative, or zero.

    
    # TODO: Check if the number is even or odd and print the message.
    # Hint: Use the modulo operator (%) to determine if a number is even or odd.

    
    # TODO: Check if the number is divisible by 5 and print the message.
    # Hint: To check if a number is divisible by 5, the remainder when divided by 5 should be 0.

    
    # Advanced Task: If the number is positive and even, check if it is also a multiple of 10.
    # Hint: Combine conditions using 'and'. A number is a multiple of 10 if the remainder when divided by 10 is 0.


if __name__ == "__main__":
    main()
