# List Operations Exercise

def main():
    # TODO: Create a list with any three items of your choice. For example, it could be fruits, gadgets, or any other items you like.
    # my_list = ["item1", "item2", "item3"]

    # TODO: Add a new item to the end of the list and print the updated list.

    # TODO: Insert a new item at index 1 and print the updated list.

    # TODO: Remove the item at index 3 and print the updated list.

    # TODO: Remove the last item in the list and print the updated list.

    # Remember: You're just starting out, so don't worry about handling errors if an index doesn't exist. That will come later!

if __name__ == "__main__":
    main()
