# Grade Calculator

def main():
    # TODO: Prompt the user for the average assignment score and convert it to a float
    assignments_score = 0  # Placeholder, replace with actual input and conversion

    # TODO: Prompt the user for the average tests score and convert it to a float
    tests_score = 0  # Placeholder, replace with actual input and conversion

    # TODO: Prompt the user for the class participation score and convert it to a float
    participation_score = 0  # Placeholder, replace with actual input and conversion

    # TODO: Calculate the final grade based on the weights: Assignments (40%), Tests (40%), Participation (20%)
    final_grade = 0  # Placeholder, replace with the calculation logic

    # Display the final grade
    print(f"Your final grade is: {final_grade}")

if __name__ == "__main__":
    main()
